---------------------------------------------------------------------------------------------------
-- load all framework prototype pieces
---------------------------------------------------------------------------------------------------

require('framework.prototypes.sprite')
require('framework.prototypes.style')
require('framework.prototypes.technology-slot-style')
